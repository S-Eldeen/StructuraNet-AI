import { Outlet, useNavigate } from 'react-router-dom';
import './dashboardLayout.css';
import ChatList from "../../components/chatList/ChatList";
import { useAuth } from '@clerk/clerk-react';
import { useEffect } from 'react';

const DashboardLayout = () => {
    const { userId, isLoaded } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (isLoaded && !userId) {
            navigate('/sign-in');
        }
    }, [isLoaded, userId, navigate]);

    if (!isLoaded) return (
        <div className="global-logo-loader">
            <div className="logo-spinner-wrapper">
                <div className="spinner-ring"></div>
                <img src="/logo.png" alt="Loading" className="spinner-logo" />
            </div>
        </div>
    );

    return (
        <div className='dashboardLayout'>
            <div className="menu"><ChatList /></div>
            <div className="content">
                <Outlet />
            </div>
        </div>
    );
};
export default DashboardLayout;